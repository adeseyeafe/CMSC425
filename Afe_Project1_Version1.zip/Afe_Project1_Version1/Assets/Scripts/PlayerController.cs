﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class PlayerController : MonoBehaviour {

	public float speed;
	public Text countText;
	public Text winText;

	private Rigidbody rb;
	public int pickupQuota;
	public Renderer rend;

	void Start ()
	{
		rb = GetComponent<Rigidbody>();
		SetCountText ();
		winText.text = "";
	}

	void FixedUpdate ()
	{
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");

		Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);

		rb.AddForce (movement * speed);
		if (pickupQuota == 0){
			if (Input.GetKeyDown (KeyCode.Keypad1) == true || Input.GetKeyDown (KeyCode.Alpha1) == true) {
				SceneManager.LoadScene (SceneManager.GetActiveScene ().buildIndex);
			}
		}
		if (Input.GetKeyDown (KeyCode.Escape) == true) {
			Application.Quit ();
		}
	}

	void OnTriggerEnter(Collider other) 
	{
		if (other.gameObject.CompareTag ( "Pickup"))
		{
			other.gameObject.SetActive (false);
			pickupQuota = pickupQuota - 1;
			SetCountText ();
		}
	}

	void SetCountText ()
	{
		countText.text = "Count: " + pickupQuota.ToString ();
		if (pickupQuota == 0)
		{
			winText.text = "You Win!\nPress ESC to quit or 1 to restart.";
			rb.isKinematic = true;
		}
	}
}
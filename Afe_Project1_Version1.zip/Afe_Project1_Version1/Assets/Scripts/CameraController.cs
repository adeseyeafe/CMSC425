﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {

	public GameObject player;
	private Vector3 offset;

	// Use this for initialization and get offset of player position
	void Start () {
		offset = transform.position - player.transform.position;
	}
	
	// Update is called once per frame after everything is done
	void LateUpdate () {
		transform.position = player.transform.position + offset;
	}
}

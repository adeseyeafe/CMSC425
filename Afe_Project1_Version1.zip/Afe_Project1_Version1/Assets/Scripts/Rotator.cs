﻿using UnityEngine;
using System.Collections;

public class Rotator : MonoBehaviour {

	public GameObject pickupPrefab;
	public GameObject[] pickups;
	public int numOfPickups;
	private float cornerAngle;
	private float progress;
	
	private GameObject thePlayer;
	private PlayerController playerScript;
	
	void Start ()
	{
		numOfPickups = 12;
		pickups = new GameObject[numOfPickups];
		thePlayer = GameObject.FindGameObjectWithTag("Player");
		playerScript = thePlayer.GetComponent<PlayerController>();
		for(int i = 0; i < numOfPickups; i++)
		{
			progress = (i * 1.0f) / numOfPickups;
			cornerAngle = progress*Mathf.PI*2;
			pickups[i] = (GameObject)Instantiate (pickupPrefab, new Vector3 (Mathf.Sin(cornerAngle)*5f, 0.5f, Mathf.Cos(cornerAngle)*5f), Quaternion.identity);
		}
	}

	// Update is called once per frame to rotate pickup objects 
	void Update () {
		if (playerScript.pickupQuota > 0){
			transform.Rotate (new Vector3 (15, 30, 45) * Time.deltaTime);
		}
	}
}

Spring 2016 - CMSC 425: Programming Assignment (1) (Part 1)
----------------------------------------------------------------

Adeseye Afe

1. Required settings
2. Extra settings
3. Additional notes

----------------------------------------------------------------
1. Required settings

1.1 numberOfPickups

A public variable in the [Player] game object (in PlayerController.cs script).

1.2 pickupQuota

A public variable in the [Player] game object (in Rotator.cs script).

1.3 Quit

Hit 'ESC'.

1.4 Restart

Hit '1' when the game ends. Please note: I wasn't sure about if there 
was a need to restart the game whenever the user(grader) wanted to since 
it wasn't specified in the project description so I just put it at the 
end. I'll ask about it for Part 2.

----------------------------------------------------------------
2. Extra settings

None

----------------------------------------------------------------
3. Additional notes

None
